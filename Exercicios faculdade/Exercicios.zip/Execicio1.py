raio = float(input("Entre com o raio da esfera: "))
pi = 3.14

diametro = raio * 2

circunferencia = diametro * pi

area = pi * (raio**2)

volume = (4 * pi * (raio**3))/3

print("O diametro e de: ",diametro,"\n")
print("A circunferencia e de: ", circunferencia,"\n")
print("A area e de: ",area,"\n")
print("O volume e de: ",diametro,"\n")